<?php
// Database connection constants
//define("DATABASE_HOST" , "98.102.204.204");
define("DATABASE_HOST" , "localhost");
//define("DATABASE_USERNAME" , "mastermind");
define("DATABASE_USERNAME" , "root");
//define("DATABASE_PASSWORD" , "Abc123456.");
//define("DATABASE_NAME" , "mastermind");
define("DATABASE_NAME" , "mms");

?>