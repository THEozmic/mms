

    <!-- Bootstrap Core JavaScript -->
    <script src="http://mastermind.niitportharcourt.com/js/bootstrap.min.js" async></script>
    
     

    <!-- jQuery easing -->
    <script src="http://mastermind.niitportharcourt.com/js/jquery.easing.js" async></script>
    <!-- moment.js-->
    <script src="http://mastermind.niitportharcourt.com/js/moment.min.js"></script>

    <!-- irrelevant javascript-->
    <script src="http://mastermind.niitportharcourt.com/js/main.js" async></script>
    <!-- Core JavaScript -->
    <script src="http://mastermind.niitportharcourt.com/js/jqBootstrapValidation.js" async></script>

    <!-- Bootstrap Core CSS -->
    <link href="http://mastermind.niitportharcourt.com/css/bootstrap.min.css" rel="stylesheet">

   
    </body>
    <script type="text/javascript">
    
        $("#content, #login-content").css({"visibility":"visible"});
    </script>

    <!-- Custom Fonts -->
    <link href="http://mastermind.niitportharcourt.com/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    </html>