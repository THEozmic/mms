<?php
session_start();
require("../requires/header.php");
require("../requires/dashboard.php");
?>
<div id="content">

    <div style="padding: 20px;">

    	<p><strong>MasterMind</strong> is an online community for NIIT students.<br>
    	The team behind this <a href="https://www.linkedin.com/in/michael-ozoemena-452335120">Michael Ozoemena</a> and <a href="https://t.co/owOxGAkoXT">Prince Atauba</a>.
    	


    	    </div>
    	    </div>
    <?php
    	require("../requires/footer.php");
    ?>