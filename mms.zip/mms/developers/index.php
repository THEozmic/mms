

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>MMStack | Question and Answer For MMS</title>
    <!-- jQuery -->
    <script src="http://mastermind.niitportharcourt.com/js/jquery.js"></script>
    <!-- moment.js-->
    <script src="http://mastermind.niitportharcourt.com/js/moment.min.js"></script>
    <!-- Bootstrap Core CSS -->
    <link href="http://mastermind.niitportharcourt.com/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="http://mastermind.niitportharcourt.com/css/main.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="http://mastermind.niitportharcourt.com/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
</head>
<!-- Navigation -->
    <nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
       <div><a href="http://mastermind.niitportharcourt.com/">MMStack</a></div>
       <div class="ma-menu">

 <div><a class="back jbutton">Go back</a></div>
        </div>
    </nav>
            

       <div class="main-content">
       <div id="mid-section" style="padding: 20px">
            <div>
            <p>Back end Developer: Michael <a href="http://twitter.com/the_ozmic">(@the_ozmic)</a></p>
            </div>

            <div>
            <p>Front End Developers: Michael <a href="http://twitter.com/the_ozmic">(@the_ozmic)</a> + Emmanuel</p>
            </div>

            <div>
            <p>Ideator: Abraham</p>
            </div>
            

       </div>
       </div>
    <?php
    require("../requires/footer.php");
    ?>